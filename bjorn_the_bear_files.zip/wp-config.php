<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** Database username */
define( 'DB_USER', 'levente_farkas' );

/** Database password */
define( 'DB_PASSWORD', 'q1w2e3r4' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'pSi>x&aWX}%#>Bq3)j4PGP_~;=/.FjLoecXl?X|2;m0tUj!,~!z1,p4_n}S>;9<]' );
define( 'SECURE_AUTH_KEY',  'paiF6QiE|E<1Qk>x!P;%LcoP--C3h</!(>W6Ltk@D.?MG<YE}Hw/i2IlPVI`Wchl' );
define( 'LOGGED_IN_KEY',    'DnLp03^kLLLHM$_u0$j|RENt%.23Mn3oWB8O6`@@GVrBPRf8?qooghB#l-sR>MFq' );
define( 'NONCE_KEY',        '`YKbGIa:8ZQU?*~#G=zB1;|<!zk!Ob)v!xz`^7Lxd_J4MTnGJe9K<7H(wr?okl;f' );
define( 'AUTH_SALT',        ']}#BXw_fBTd(8=#[S<~LghUSNw+_K%IFATD)U7PnYAWXsw0.#l`y5|:oSBeRj?p%' );
define( 'SECURE_AUTH_SALT', 'Tcq5`)uaWsqM@(7aZHJ}`PPE`ggNFj=$s[q~J9.b1Y*8?,#%;nPQZQXe&-c!81>u' );
define( 'LOGGED_IN_SALT',   'IMu<7GC|2sC2u(mx=w;6|qls2YEKPz5%jGK3k>jz-9WU Ls`y?;GXkaU@IrIQ{!*' );
define( 'NONCE_SALT',       '42z}HUkr[Gn9K}xWM0hxv-k9DEq#7?,c|HLmq@0o_C4*A;dSrF%QoG0ysWPiD HV' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
